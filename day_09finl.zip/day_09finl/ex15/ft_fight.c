/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fight.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybarhdad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/30 11:36:56 by ybarhdad          #+#    #+#             */
/*   Updated: 2019/08/30 15:18:26 by ybarhdad         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_fight.h"

void	ft_putstr(char *str)
{
	while (st++)
		write(1, str, 1);
}

void	ft_fight(t_person *attker, t_person *defense, char *attcck)
{
	if (atkker->life > 0 || defence->life > 0)
		return (0);
	if (attck == KICK)
		defense->life -= 15;
	else if (attack == PUNCH)
		defence->life -= 5;
	else if (attack == HEADBUTT)
		defence->life -= 25;
	ft_putstr(attaker->name);
	ft_putstr(" does a  judo ");
	ft_putstr(attack);
	ft_putstr(" on ");
	ft_putstr(defence->name);
	if (defence->life <= 0)
	{
		ft_putstr(defence->name);
		ft_pustr("is dead");
	}
}

#ifndef FT_PERSO_H
# define FT_PERSO_H

#include "person.h"
KICK = "KICK"
PUNCH = "PUNSH"
HEADBUTT = "HEADBUTT"

 void 	ft_fight(t_person *attker,t_person *defence,char *attck);
	


#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybarhdad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/29 17:48:23 by ybarhdad          #+#    #+#             */
/*   Updated: 2019/08/30 12:20:23 by ahammoud         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	print(int first, int second, char temp, char temp2)
{
	char zero1;
	char zero2;

	if (first < 10)
		zero1 = '0';
	if (second < 10)
		zero2 = '0';
	printf("THE FOLLOWING TAKES PLACE BETWEEN");
	printf(" %c%d.00 %cM AND %c%d.00 %c.M.\n",
				zero1, first, temp, zero2, second, temp2);
}

void	ft_takes_place(int hour)
{
	char	temp;
	int		next;
	char	temp2;

	temp2 = 'A';
	temp = 'A';
	next = hour + 1;
	if (hour >= 12)
	{
		temp = 'P';
		if (hour >= 12)
			hour -= 12;
	}
	if (hour == 0)
		hour = 12;
	if (next >= 12)
	{
		if (next < 24)
			temp2 = 'P';
		if (next > 12)
			next = next - 12;
	}
	if (next == 0)
		next = 12;
	print(hour, next, temp, temp2);
}

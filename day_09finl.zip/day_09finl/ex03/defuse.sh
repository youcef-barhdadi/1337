touch -r bomb.txt -A '-000001' bomb.txt | ls -lT bomb.txt | awk -F " " '{print$8}'

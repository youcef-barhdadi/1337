/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_active_bits.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybarhdad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/30 12:15:17 by ybarhdad          #+#    #+#             */
/*   Updated: 2019/08/30 13:16:52 by ahammoud         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_active_bits(int value)
{
	int i;

	i = 0;
	if (value == 0)
		return (0);
	if (i < 0)
	{
		i += 1;
		value *= -1;
	}
	while (value / 2 != 1)
	{
		if (value % 2 != 0)
			i++;
		value = value / 2;
	}
	return (i);
}

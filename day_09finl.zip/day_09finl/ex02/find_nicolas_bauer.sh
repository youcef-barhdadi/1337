curl -s https://projects.intra.42.fr/uploads/document/document/266/contacts_hard.txt |grep -i "nicolas" | grep -i Bauer | grep '[0-9]\{3\}-[0-9]\{4\}' | rev | awk -F " " '{print$2}' | rev

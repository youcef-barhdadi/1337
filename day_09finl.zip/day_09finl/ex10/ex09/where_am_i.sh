#!/bin/bash

num_a=400

if [$ip -eq ""] ; then
   	echo  heloo	
else
	echo hi
fi

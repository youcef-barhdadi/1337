alias rm="ls"

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybarhdad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/30 01:55:35 by ybarhdad          #+#    #+#             */
/*   Updated: 2019/08/30 16:06:53 by ybarhdad         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strlowcase(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 65 && str[i] <= 90)
		{
			str[i] += 32;
		}
		i++;
	}
	return (str);
}

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int		ft_strcmp(char *str, char *tofind)
{
	int lent;
	int i;

	lent = ft_strlen(tofind);
	i = 0;
	while (*str == ' ')
	{
		str++;
	}
	while (*str && (*str == *tofind))
	{
		i++;
		str++;
		tofind++;
	}
	if (i == lent)
		return (0);
	return (1);
}

int		main(int argc, char **argv)
{
	int		i;
	char	*c;

	i = 1;
	while (i < argc)
	{
		c = ft_strlowcase(argv[i]);
		if (ft_strcmp(c, "president") == 0 ||
				ft_strcmp(c, "attack") == 0 || ft_strcmp(c, "bauer") == 0)
		{
			write(1, "Alert!!!", 8);
			return (0);
		}
		i++;
	}
	return (0);
}

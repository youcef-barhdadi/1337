/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_collatz_conjecture.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybarhdad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/30 01:24:01 by ybarhdad          #+#    #+#             */
/*   Updated: 2019/08/30 16:06:17 by ybarhdad         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int		ft_collatz_conjecture(unsigned int base)
{
	if (base == 1)
		return (0);
	if (base % 2 == 0)
	{
		return (1 + ft_collatz_conjecture(base / 2));
	}
	else
	{
		return (1 + ft_collatz_conjecture(base * 3 + 1));
	}
}

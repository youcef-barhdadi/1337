/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_antidote.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybarhdad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/30 16:03:35 by ybarhdad          #+#    #+#             */
/*   Updated: 2019/08/30 16:04:09 by ybarhdad         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_antidote(int i, int j, int k)
{
	int		mid;

	mid = 0;
	if (i < j)
	{
		if (j < k)
			mid = j;
		else
			mid = k;
	}
	else if (j < i)
	{
		if (i < k)
			mid = i;
		else
			mid = k;
	}
	return (mid);
}
